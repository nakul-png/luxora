import Navbar from "../../../components/Navbar";
import products from "../../../data/products";
import Image from "next/image";

export default async function ProductPage({ params }) {
  const { id } = await params;

  const product = products.find((item) => item.id === id);

  if (!product) {
    return (
      <>
        <Navbar />
        <main
          style={{
            padding: "120px 60px",
            color: "white",
            background: "#000",
            minHeight: "100vh",
          }}
        >
          <h1>Product Not Found</h1>
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="product-page">
        <div className="product-container">

          <div className="product-image">
            <Image
              src={product.image}
              alt={product.name}
              width={450}
              height={550}
            />
          </div>

          <div className="product-details">

            <div className="product-header">
              <h1>{product.name}</h1>

              <button className="wishlist-btn">
                ❤️
              </button>
            </div>

            <div className="product-rating">
              ⭐⭐⭐⭐⭐
              <span>(128 Reviews)</span>
            </div>

            <h2 className="product-price">
              ₹{product.price}
            </h2>

            <h3>Select Size</h3>

            <div className="sizes">
              <button>S</button>
              <button>M</button>
              <button>L</button>
              <button>XL</button>
            </div>

            <h3>Quantity</h3>

            <div className="quantity-box">
              <button>-</button>
              <span>1</span>
              <button>+</button>
            </div>

            <p className="product-description">
              {product.description}
            </p>

            <div className="product-buttons">
              <button className="buy-btn">
                Add to Cart
              </button>

              <button className="checkout-btn">
                Buy Now
              </button>
            </div>

          </div>

        </div>
      </main>
    </>
  );
}